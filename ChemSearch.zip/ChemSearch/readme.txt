ChemicalSearch source and bin details 
=====================================
- Create .NET web app project in VS2015
- Add JQuery to the project
- Add Jquery mobile CSS files
- Use some images for missing (not added due to size) for background use.
- Use Font awesome
- Copy the source files to your project source (all files are placed as .Txt to avoid filtering)
- copy paste following source files in your project
	* Global.asax
	* Entities.cs
	* Chemsearch.aspx
- Change the namespaces and classes as required.

** Also the compiled DLL with data XML is given to directly install as a webapp in IIS.
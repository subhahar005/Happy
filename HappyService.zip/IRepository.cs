﻿namespace HappyCommon
{
    public interface IRepository
    {
    }
}